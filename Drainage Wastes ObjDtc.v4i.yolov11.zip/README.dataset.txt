# Drainage Wastes ObjDtc > 2024-02-03 8:26pm
https://universe.roboflow.com/biodrainergy-workspace1/drainage-wastes-objdtc

Provided by a Roboflow user
License: CC BY 4.0

